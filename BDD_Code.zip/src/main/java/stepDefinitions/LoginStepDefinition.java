package stepDefinitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {
	
	@Given("^user is already on main page$")
	public void already_on_main_page(){
		System.out.println("already_on_main_page");
	}
	
	@When("^title of page is Online shopping site$")
	public void title_of_page_is_Online_shopping_site() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("title_of_page_is_Online_shopping_site");

	}

	@Then("^click on sign in button$")
	public void click_on_sign_in_button() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("click_on_sign_in_button");

	}

	@Then("^enter username / email id and click continue$")
	public void enter_username_email_id_and_click_continue() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("enter_username_email_id_and_click_continue");

	}

	@Then("^enter password and click login button$")
	public void enter_password_and_click_login_button() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("enter_password_and_click_login_button");
	}

	@And("^user is on home page$")
	public void user_is_on_home_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("user_is_on_home_page");
	}



}
