package testRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="E:\\Work\\JavaLearningClasses2\\AmazonBDDFramework\\src\\main\\java\\featureFiles\\login.feature"
		,glue={"stepDefinitions"} // path to step definitions
		,plugin={"pretty","html:test-output"} // to provide readable format and generation of log
		,monochrome=true // readable output on console
		,dryRun=false // try to map feature file definition with step definition	and reports discrepancies
		
		)


public class TestRunner {

}
